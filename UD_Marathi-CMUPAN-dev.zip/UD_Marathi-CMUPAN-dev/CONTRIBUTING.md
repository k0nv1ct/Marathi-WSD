# Contributing

Please do not make pull requests against master, any such pull requests will be
closed. Instead make them against the dev branch.

For full details on the branch policy see
[here](http://universaldependencies.org/release_checklist.html#repository-branches).
